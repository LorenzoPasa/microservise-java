INSERT INTO tb_product (description, brand, model, currency, price, stock) VALUES
                       ('Notebook Aspire 5', 'Acer', 'Aspire 5 A515-45-R760', 'BRL', 3299.90, 15),
                       ('Smart TV 50" 4K', 'LG', '50UQ801C0SB', 'BRL', 2299.00, 8),
                       ('Fone Bluetooth WH-CH520', 'Sony', 'WH-CH520', 'BRL', 279.99, 25),
                       ('Monitor 24" LED', 'Samsung', 'LF24T350FHLMZD', 'BRL', 749.90, 12),
                       ('Caixa de Som JBL Go 3', 'JBL', 'GO 3', 'BRL', 199.00, 20);
