INSERT INTO tb_product (description, brand, model, currency, price, stock) VALUES
('Iphone 15 256', 'Apple', 'iPhone 15 256GB', 'USD', 1022.96, 10),
('Moto G85 256', 'Motorola', 'G85 256GB', 'USD', 306.78, 10),
('Redmi 13c 256', 'Xiaomi', 'Redmi 13c 256GB', 'USD', 242.15, 10),
('S23 Ultra 256', 'Samsung', 'S23 Ultra 256GB', 'USD', 768.70, 10);
