INSERT INTO tb_currency (source_currency, target_currency, conversion_rate) VALUES
  ('USD', 'BRL', 5.73),
  ('USD', 'EUR', 0.84),
  ('USD', 'GBP', 0.73),
  ('USD', 'ARS', 92.56),
  ('USD', 'CLP', 713.30),
  ('USD', 'COP', 3665.00),
  ('USD', 'MXN', 20.15);