package br.edu.atitus.currency_service.clients;

public class Currency {
    private double cotacaoVenda;

    public double getCotacaoVenda() {
        return cotacaoVenda;
    }
    public void setCotacaoVenda(double cotacaoVenda) {
        this.cotacaoVenda = cotacaoVenda;
    }
}
